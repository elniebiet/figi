@extends('layout')

@section('title','Sign-up')
@section('content')

     <div class="row">
            <div class="col-sm-3"></div>
            <div class="col-sm-6">
             
              <div class="card mb-4" id="s1">
                  <div class="card-body">
                      <div class="text-center">
                          <h1 class="blue-text"><i class="fas fa-user prefix"></i></h1>
                          <h5 class="card-title grey-text">SIGN-UP-<small>Verification code</small></h5>
                      </div>    
                      <form class="p-5 grey-text">
                        <div class="md-form form-sm">
                          <p class="card-text text-center">An sms has been sent to your phone number.Enter the verification code **** below.</p>
                        </div>
                        <div class="md-form form-sm"> <i class="fas fa-lock prefix"></i>
                          <input type="text" id="vcode" class="form-control form-control-sm" required="required">
                          <label for="vcode">Verification code</label>
                          <small id="vcodeHelp" class="form-text text-muted red-text"></small>
                        </div>
                        <div class="text-center mt-4">
                          <button class="btn btn-primary" id="verifybtn">Verify<i class="fas fa-paper-planeml-1"></i></button>
                        </div>
                      </form>
                  </div>
                </div>
                <!--Card end-->
          
                <!--Toggle display of cards after each step-->
                <div class="card mb-4" id="s2" style="display:none;">
                    <div class="card-body" id="termsconditions" style="height: 400px;
    overflow-y: scroll; ">
                        <div class="text-center">
                            <h1 class="blue-text"><i class="fas fa-user prefix"></i></h1>
                            <h5 class="card-title grey-text">SIGN-UP-<small>Term and conditions</small></h5>
                        </div>    
                        <div class="p-5 grey-text">
                            <p class="text-justify">The background images for the slider are set directly in the HTML using inline CSS. The images in this snippet are from <a href="#">Unsplash</a>, taken by <a href="#">Joanna Kosinska</a>!</p>
                            <p class="text-justify">The background images for the slider are set directly in the HTML using inline CSS. The images in this snippet are from <a href="#">Unsplash</a>, taken by <a href="#">Joanna Kosinska</a>!</p>
                            <p class="text-justify">The background images for the slider are set directly in the HTML using inline CSS. The images in this snippet are from <a href="#">Unsplash</a>, taken by <a href="#">Joanna Kosinska</a>!</p>
                            <p class="text-justify">The background images for the slider are set directly in the HTML using inline CSS. The images in this snippet are from <a href="#">Unsplash</a>, taken by <a href="#">Joanna Kosinska</a>!</p>
                            <p class="text-justify">The background images for the slider are set directly in the HTML using inline CSS. The images in this snippet are from <a href="#">Unsplash</a>, taken by <a href="#">Joanna Kosinska</a>!</p>
                            <p class="text-justify">The background images for the slider are set directly in the HTML using inline CSS. The images in this snippet are from <a href="#">Unsplash</a>, taken by <a href="#">Joanna Kosinska</a>!</p>
                            <p class="text-justify">The background images for the slider are set directly in the HTML using inline CSS. The images in this snippet are from <a href="#">Unsplash</a>, taken by <a href="#">Joanna Kosinska</a>!</p>
                            <div class="text-center mt-4">
                                <div class="btn-toolbar" role="toolbar" aria-label="Toolbar with button groups">
                                    <div class="btn-group" role="group" aria-label="Second group">
                                      <button type="button" class="btn btn-primary" id="agree" onclick=" toggledisplay('s2');
                      toggledisplay('s3');">I Agree</button>
                                    </div>
                                    <div class="btn-group ml-auto" role="group" aria-label="Third group">
                                      <a href="index"><button type="button" class="btn btn-primary" id="notagree">I Do not Agree</button></a>
                                    </div>
                                  </div>
                            </div>
                        </div>
                    </div>
                  </div>
                  <!--Card end-->
                  <!--Toggle display based on active card-->
                <div class="card mb-4" style="display:none;" id="s3">
                    <div class="card-body">
                        <div class="text-center">
                            <h1 class="blue-text"><i class="fas fa-user prefix"></i></h1>
                            <h5 class="card-title grey-text">SIGN-UP-<small>Login details</small></h5>
                        </div>    
                        <form class="p-5 grey-text">
                          <div class="md-form form-sm" id="finishmsg">
                            <p class="card-text text-center text-orange">You are almost done! Provide your username and password to finish.</p>
                            
                          </div>
                          <div class="md-form form-sm"> <i class="fas fa-user prefix"></i>
                            <input type="text" id="username" class="form-control form-control-sm" required="required" autocomplete="off">
                            <label for="username">Username</label>
                          </div>
                          <div class="md-form form-sm"> <i class="fas fa-lock prefix"></i>
                            <input type="password" id="password" class="form-control form-control-sm" required="required">
                            <label for="password">Password</label>
                          </div>
                          <div class="md-form form-sm"> <i class="fas fa-lock prefix"></i>
                            <input type="password" id="cpassword" class="form-control form-control-sm" required="required">
                            <label for="cpassword">Confirm Password</label>
                          </div>
                          <p class="card-text text-center red-text" id="passworderror"></p>
                          <div class="text-center mt-4">
                            <button class="btn btn-primary" id="finish">Finish<i class="fas fa-paper-planeml-1"></i></button>
                          </div>
                        </form>
                    </div>
                  </div>
                  <!--Card end-->

            </div>
          <div class="col-sm-3"></div>
        </div>   
    <script type="text/javascript">
      function toggledisplay(id){
        var contentId=document.getElementById(id);
        contentId.style.display == "none" ? contentId.style.display = "block" : 
contentId.style.display = "none"; 

      }

    </script> 
     <script type="text/javascript">
        $(document).ready(function(){
          var fname = "{{ app('request')->input('fname')  }}";
          var phone = "{{ app('request')->input('p')  }}";
          var urlvcode = "{{ app('request')->input('vc')  }}";
          
          $('#verifybtn').click(function(e){
            e.preventDefault();
            var vcode = document.getElementById("vcode");
            
            $.ajaxSetup({
                headers: {
                      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            }); 
            jQuery.ajax({ 
                  url: "{{ url('/signup') }}",
                  method: 'post',
                  data: {
                     code: vcode.value
                  },
                  success: function(result){
                    var code = result.data;
                    
                    if(urlvcode==code){
                      document.getElementById("vcodeHelp").innerHTML= "Wrong Verification code provided";
                      vcode.value="";
                    }else{
                      vcode.value="";
                      toggledisplay('s1');
                      toggledisplay('s2');
                    }

                    
                  }});
 
                      });
        });
        


      </script> 
     <script type="text/javascript">
        $(document).ready(function(){
          var fname = "{{ app('request')->input('fname')  }}";
          var phone = "{{ app('request')->input('p')  }}";
          var urlvcode = "{{ app('request')->input('vc')  }}";
          
          $('#finish').click(function(e){
            
            var uname = document.getElementById("username");
            var password = document.getElementById("password");
            var cpassword = document.getElementById("cpassword");
            
            if(password.value.length<8){

                      document.getElementById("passworderror").innerHTML= "Password should be 8 or more characters";
                      password.value="";
            }else if(password.value!=cpassword.value){
                      document.getElementById("passworderror").innerHTML= "Password does not match";
                      password.value="";
                      cpassword.value="";
            }else{
                  e.preventDefault();   
              $.ajaxSetup({
                  headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                  }
              }); 
              jQuery.ajax({ 
                    url: "{{ url('/signup') }}",
                    method: 'post',
                    data: {
                       username: uname.value,
                       password: password.value,
                       firstname: fname,
                       phonenumber: '+'.phone,
                       type: 'finish'
                    },
                    success: function(result){
                      
                      
                      document.getElementById('finishmsg').innerHTML=result.data;
                      
                    }});
          }   
   
                      });
        });
        


      </script> 
      
@endsection
        