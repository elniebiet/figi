<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="csrf-token" content="{{ csrf_token() }}">
  <title>@yield('title','FIGI-Building Wealth and  Happiness')</title>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="{{ URL::asset('https://use.fontawesome.com/releases/v5.7.0/css/all.css') }}">
  <!-- Bootstrap core CSS -->
  <link href="{{ URL::asset('css/bootstrap.min.css') }}" rel="stylesheet">
  <!-- Material Design Bootstrap -->
  <link href="{{ URL::asset('css/mdb.min.css') }}" rel="stylesheet">
  <!-- Your custom styles (optional) -->
  <link href="{{ URL::asset('css/style.css') }}" rel="stylesheet">
  <link rel="stylesheet" href="{{ URL::asset('css/style3.css') }}">
  <link rel="stylesheet" href="{{ URL::asset('css/style2.css') }}">
  <link rel="icon" href="{{ URL::asset('img/logo/favicon.ico') }}">
    <!-- JQuery -->
  <script type="text/javascript" src="{{ URL::asset('js/jquery-3.3.1.min.js') }}"></script>
</head>

<body>
<!--Header to be included here-->
<header>
        <div class="wrapper">
            <!--Sidebar-->  
            <nav id="sidebar">
                <div id="dismiss">
                    <i class="fas fa-arrow-left"></i>
                </div>
        
                <div class="sidebar-header">
                    <h3>APPS</h3>
                </div>
                <ul class="list-unstyled CTAs">
                    <li>
                        <a href="index" class="download">FIGI</a>
                    </li>
                    <li>
                        <a href="#" class="article">HOUSE9ja</a>
                    </li>
                    <li>
                        <a href="#" class="article">NITTAN</a>
                    </li>
                    <li>
                        <a href="#" class="article">SEYA</a>
                    </li>
                </ul>
            </nav>
          </div>   
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light bg-dark">
      <div class="container">
          <button type="button" id="sidebarCollapse" class="btn btn-info">
              <i class="fas fa-align-left"></i>
              <span>APPS</span>
          </button>
        <a class="navbar-brand" href="#"><img src="img/logo/FIGI LOGO.jpg" style="width: 100px;"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon" style="color: #33b5e5;"></span>
            </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav smooth-scroll">
                        <li class="nav-item">
                          <a class="nav-link" href="index.html">Dashboard
                                <span class="sr-only">(current)</span>
                          </a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" href="#about">Account</a>
                        </li>
                        <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                                    Services
                                </a>
                                <div class="dropdown-menu">
                                  <a class="dropdown-item" href="#">Take Loan</a>
                                  <a class="dropdown-item" href="#">Save</a>
                                  <a class="dropdown-item" href="#">Transfer</a>
                                </div>
                              </li>
                    </ul>            
          <ul class="navbar-nav ml-auto smooth-scroll">
                <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                                <i class="fas fa-user prefix"></i>Username
                        </a>
                        <div class="dropdown-menu">
                          <a class="dropdown-item" href="profile">Profile</a>
                          <a class="dropdown-item" href="#">Logout</a>
                        </div>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#contact">Help</a>
                </li>      
          </ul>
        </div>
      </div>
    </nav>
</header>
<!--main content-->
<main>

    <div class="mt-5">
        <div class="container">
          @yield('content');
            <a title="back to top" id="back2Top" href="#" class="orange-text">&#10148</a>
        </div>
      </div>
    
</main>
<!--Main content-->
<!--Footer to be included here-->
  <!-- /Start your project here-->

  <!-- SCRIPTS -->

  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="{{ URL::asset('js/popper.min.js') }}"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="{{ URL::asset('js/bootstrap.min.js') }}"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="{{ URL::asset('js/mdb.js') }}"></script>
  <!--Google Maps-->
<!-- jQuery Custom Scroller CDN -->
<script src="{{ URL::asset('https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.concat.min.js') }}"></script>
  
  <script>
      $('.carousel').carousel({
        interval: 3000,
      })
    </script>
    <script type="text/javascript">
      $(document).ready(function () {
          $("#sidebar").mCustomScrollbar({
              theme: "minimal"
          });

          $('#dismiss, .overlay').on('click', function () {
              $('#sidebar').removeClass('active');
              $('.overlay').removeClass('active');
          });

          $('#sidebarCollapse').on('click', function () {
              $('#sidebar').addClass('active');
              $('.overlay').addClass('active');
              $('.collapse.in').toggleClass('in');
              $('a[aria-expanded=true]').attr('aria-expanded', 'false');
          });
      });
  </script>
  <script type="text/javascript">
  /*Scroll to top when arrow up clicked BEGIN*/
      $(window).scroll(function() {
          var height = $(window).scrollTop();
          if (height > 100) {
              $('#back2Top').fadeIn();
          } else {
              $('#back2Top').fadeOut();
          }
      });
      $(document).ready(function() {
          $("#back2Top").click(function(event) {
              event.preventDefault();
              $("html, body").animate({ scrollTop: 0 }, "slow");
              return false;
          });
      
      });
       /*Scroll to top when arrow up clicked END*/
       </script>
    <!-- Google Maps settings -->
</body>

</html>
