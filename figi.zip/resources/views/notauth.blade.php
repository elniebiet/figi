@extends('layout')

@section('title','FIGI-invalid user')
@section('content')

<div class="alert alert-danger">
	@if($e==0)
	<p>{{ $username }} does not exist. <span class="blue-text">Go to login.</span></p>
	@else if($e==1)
	<p>Invalid password provided for {{ $username }} . <span class="blue-text">Go to login.</span></p>
	@else if($e==2)
	<p> {{ $username }} account is inactive. <span class="blue-text">Contact admin to activate your account.</span></p>
	@else
	<p>Invalid login details. <span class="blue-text">Go back to login.</span></p>
	@endif
	
</div>
@endsection