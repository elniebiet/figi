@extends('user_logged_layout')

@section('title','username')
@section('content')
            <section id="services">
                    <!--Grid row-->
                <div class="row mt-5">
                    <div class="col-md-3 d-none d-md-block">
                            <div class="wrapper">
                                    <!--Sidebar-->  
                                    <nav id="usidebar">
                                            <div class="sidebar-header">
                                                    <h5>QUICK LINKS</h5>
                                            </div>
                                        <ul class="list-unstyled CTAs">
                                            <li>
                                                <a href="#" class="article">Profile</a>
                                            </li>
                                            <li>
                                                <a href="#" class="article">Account</a>
                                            </li>
                                            <li class="nav-item dropdown">
                                                    <a class=" article dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                                                        Services
                                                    </a>
                                                    <div class="dropdown-menu">
                                                      <a class="dropdown-item" href="#">Take Loan</a>
                                                      <a class="dropdown-item" href="#">Save</a>
                                                      <a class="dropdown-item" href="#">Transfer</a>
                                                    </div>
                                                  </li>
                                        </ul>
                                    </nav>
                                  </div>   
                    </div>
                    <div class="col-md-6 col-sm-12">
                    <!--Grid column-->

                            <div class="card">
                                <div class="card-body">
                                       
                                    <div class="p-5 grey-text">
                                          <div class="grey-text">
                                            <h4 class="card-title">My Loans</h4>
                                            <hr class="bg-dark">
                                            <div class="mt-4">
                                                <a class="card-link" href="#">Go to account</a>
                                                <p class="card-text">You do not have a loan application currently. </p>
                                          </div>
                                           </div>
                                          <div class="mt-5 grey-text">
                                            <h4 class="card-title grey-text">My Account</h4>
                                            <hr class="bg-dark">
                                            <p class="card-text">Manage your account. View loan progress, account transaction history</p>
                                            <div class="mt-4">
                                              <a class="card-link" href="#">Go to account</a>
                                            </div>
                                                    
                                          </div>
                                    </div>
                                </div>
                              </div>
                              <!--Card end-->
                            
                    </div>
                    <div class="col-md-3 col-sm-12">
                        <!--Grid column-->
                                <div class="card">
                                    <div class="card-body">
                                        <div class="text-center">
                                            <h1 class="blue-text"><i class="fas fa-user prefix"></i></h1>
                                            <h5 class="card-title grey-text">PROFILE</h5>
                                        </div>    
                                        <div class="p-5 grey-text">
                                              <p class="card-text">Query some profile details here</p>
                                           
                                          <div class="mt-4">
                                            <a class="card-link" href="#">Continue to profile</a>
                                          </div>
                                          
                                        </div>
                                    </div>
                                  </div>
                                  <!--Card end-->
                            
                        </div>
                </div>
            </section>                
   @endsection         