<?php /* C:\xampp\htdocs\figi\resources\views/profile.blade.php */ ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>FIGI-Building Wealth and  Happiness</title>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css">
  <!-- Bootstrap core CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!-- Material Design Bootstrap -->
  <link href="css/mdb.min.css" rel="stylesheet">
  <!-- Your custom styles (optional) -->
  <link href="css/style.css" rel="stylesheet">
  <link rel="stylesheet" href="css/style3.css">
  <link rel="stylesheet" href="css/style2.css">
  <link rel="icon" href="img/logo/favicon.ico">
</head>

<body>
        <!-- login modal --> 
        <div class="modal fade" id="personaldetails" tabindex="-1" role="dialog" aria-labelledby="contact" aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" >Personal Details</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                    <p style="color: red; font-size: 16px;" id="errormessage"> </p>
                    <form class="p-5 grey-text">
                        <div class="md-form form-sm">
                            <label for="firstname">Firstname</label>
                            <input type="text" id="firstname" name="firstname"  maxlength="20" value="<?php echo $firstname; ?>" class="form-control ">
                        </div>
                        <div class="md-form form-sm">
                          <input type="text" id="middlename" name="middlename" maxlength="20" class="form-control">
                          <label for="middlename">Middlename</label>
                        </div>
                        <div class="md-form form-sm">
                            <input type="text" id="surname" name="surname"  maxlength="20" class="form-control">
                            <label for="surname">Surname</label>
                        </div>
                        <div class="md-form form-sm">
                              <input type="text" id="phone" name="phone" value="<?php echo $phone; ?>" class="form-control" maxlength="14">
                              <label for="phone">Phone number</label>
                        </div>
                        <div class="md-form form-sm">
                            <input type="text" id="line1" name="line1" class="form-control ">
                            <label for="line1">Address line 1</label>
                        </div>
                        <div class="md-form form-sm">
                          <input type="text" id="line2" name="line2" class="form-control">
                          <label for="line2">Address line 2</label>
                        </div>
                        <div class="md-form form-sm">
                            <option value="">Select State</option>
                            <select  id="state" name="state" class="custom-select">
                              <?php 
                                $filecontents = Storage::disk('local')->get('nigerianstatesandlgas.json');
                                $array = json_decode($filecontents, true);
                                $i = 0;
                                for($i=0; $i<count($array); $i++){
                                  $state = "";
                                  $state = $state.'<option value="'.$array[$i]["state"]["name"].'"';
                                  $state = $state.'>';
                                  $state = $state.$array[$i]["state"]["name"];
                                  $state = $state.'</option>';
                                  echo $state;
                                }
                                
                              ?>
                            </select>
                            
                        </div>
                        <div class="md-form form-sm">
                            <select  id="lga" name="lga" class="custom-select">
                              <option value="">L.G.A</option>
                              <option value="single">Bwari</option>
                              <option value="married">Gwagwalada</option>
                            </select>
                        </div>
                        <div class="md-form form-sm">
                            <input type="date" id="dob" name="dob" class="form-control">
                            <label for="dob">Date of Birth</label>
                        </div>
                        <div class="md-form form-sm">
                            <select  id="marital" name="marital" class="custom-select">
                                <option value="">Select marital status</option>
                              <option value="single">Single</option>
                              <option value="married">Married</option>
                            </select>
                        </div>
                        <div class="md-form form-sm">
                          <input type="text" id="nextkin" name="nextkin" class="form-control">
                          <label for="nextkin">Next of Kin</label>
                        </div>
                        <div class="md-form form-sm">
                            <input type="text" id="nextkinphone" name="nextkinphone" class="form-control">
                            <label for="nextkinphone">Next of kin phone number</label>
                        </div>
                        <div class="md-form form-sm">
                            <input type="text" id="nextkinline1" name="nextkinline1" class="form-control">
                            <label for="nextkinline1">Next of Kin Address line 1</label>
                        </div>
                        <div class="md-form form-sm">
                          <input type="text" id="nextkinline2" name="nextkinline2" class="form-control">
                          <label for="nextkinline2">Next of Kin Address line 2</label>
                        </div>
                        <div class="text-center mt-4">
                         
                          <button class="btn btn-primary"id="btnpersonal" name="btnpersonal" type="button">Submit</button>
                        </div>
                      </form>
                    
                </div>
                <div class="modal-footer">
            
                </div>
              </div>
            </div>
          </div>
        <!-- login modal -->
        <!-- login modal -->
        <div class="modal fade" id="bankdetails" tabindex="-1" role="dialog" aria-labelledby="contact" aria-hidden="true">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h5 class="modal-title" >Bank Details</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div class="modal-body">
                    <form class="p-5 grey-text">
                        <div class="md-form form-sm">
                          <input type="text" id="form3" class="form-control form-control-sm">
                          <label for="form3">Enter Bank name</label>
                        </div>
                        <div class="md-form form-sm">
                          <input type="text" id="form2" class="form-control form-control-sm">
                          <label for="form2">Enter Bank account number</label>
                        </div>
                        <div class="md-form form-sm">
                          <!--Use BVN to check if bank account is a personal account and not company-->
                          <input type="text" id="form2" class="form-control form-control-sm">
                          <label for="form2">Enter bank account type</label>
                        </div>
                        <div class="md-form form-sm">
                            <input type="text" id="form2" class="form-control form-control-sm">
                            <label for="form2">Enter your BVN</label>
                          </div>
                        <div class="text-center mt-4">
                          
                          <button class="btn btn-primary">Submit</button>
                        </div>
                      </form>
                    
                </div>
                <div class="modal-footer">
                  
                </div>
              </div>
            </div>
          </div>
        <!-- login modal -->
                

<!--Header to be included here-->
<header>
        <div class="wrapper">
            <!--Sidebar-->  
            <nav id="sidebar">
                <div id="dismiss">
                    <i class="fas fa-arrow-left"></i>
                </div>
        
                <div class="sidebar-header">
                    <h3>APPS</h3>
                </div>
                <ul class="list-unstyled CTAs">
                    <li>
                        <a href="#" class="download">FIGI</a>
                    </li>
                    <li>
                        <a href="#" class="article">HOUSE9ja</a>
                    </li>
                    <li>
                        <a href="#" class="article">NITTAN</a>
                    </li>
                    <li>
                        <a href="#" class="article">SEYA</a>
                    </li>
                </ul>
            </nav>
          </div>   
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light bg-dark">
      <div class="container">
          <button type="button" id="sidebarCollapse" class="btn btn-info">
              <i class="fas fa-align-left"></i>
              <span>APPS</span>
          </button>
        <a class="navbar-brand" href="#"><img src="img/logo/FIGI LOGO.jpg" style="width: 100px;"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon" style="color: #33b5e5;"></span>
            </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav smooth-scroll">
                        <li class="nav-item active">
                          <a class="nav-link" href="index.html">Dashboard
                                <span class="sr-only">(current)</span>
                          </a>
                        </li>
                        <li class="nav-item">
                          <a class="nav-link" href="#about">Account</a>
                        </li>
                        <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                                    Services
                                </a>
                                <div class="dropdown-menu">
                                  <a class="dropdown-item" href="#">Take Loan</a>
                                  <a class="dropdown-item" href="#">Save</a>
                                  <a class="dropdown-item" href="#">Transfer</a>
                                </div>
                              </li>
                    </ul>            
          <ul class="navbar-nav ml-auto smooth-scroll">
                <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                                <i class="fas fa-user prefix"></i>Username
                        </a>
                        <div class="dropdown-menu">
                          <a class="dropdown-item" href="#">Profile</a>
                          <a class="dropdown-item" href="#">Logout</a>
                        </div>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#contact">Help</a>
                </li>      
          </ul>
        </div>
      </div>
    </nav>
          </header>
<!--main content-->
<main>

    <div class="mt-5">
        <div class="container">
                          
            <section id="services">
                    <!--Grid row-->
                <div class="row mt-5">
                    <div class="col-md-3 d-none d-md-block">
                            <div class="wrapper">
                                    <!--Sidebar-->  
                                    <nav id="usidebar">
                                            <div class="sidebar-header">
                                                    <h5>QUICK LINKS</h5>
                                            </div>
                                        <ul class="list-unstyled CTAs">
                                            <li>
                                                <a href="#" class="download">Profile</a>
                                            </li>
                                            <li>
                                                <a href="#" class="article">Account</a>
                                            </li>
                                            <li class="nav-item dropdown">
                                                    <a class=" article dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                                                        Services
                                                    </a>
                                                    <div class="dropdown-menu">
                                                      <a class="dropdown-item" href="#">Take Loan</a>
                                                      <a class="dropdown-item" href="#">Save</a>
                                                      <a class="dropdown-item" href="#">Transfer</a>
                                                    </div>
                                                  </li>
                                        </ul>
                                    </nav>
                                  </div>   
                    </div>
                    <div class="col-md-9 col-sm-12">
                    <!--Grid column-->
                        <div class="card-deck">
                            <div class="card">
                                <div class="card-body">
                                    <div class="text-center">
                                        <p id="personaldetailssuccess" style="color: red; font-size: 16px;"></p>
                                        <h1 class="blue-text"><i class="fas fa-user prefix"></i></h1>
                                        <h5 class="card-title grey-text">Personal Details</h5>
                                    </div>    
                                    <div class="p-5 grey-text">
                                          <p class="card-text">Query all personal details here</p>
                                       
                                      <div class="mt-4">
                                        <a class="card-link" href="#" data-toggle="modal" data-target="#personaldetails">Update </a>
                                      </div>
                                      
                                    </div>
                                </div>
                              </div>
                              <!--Card end-->
                        <div class="card">
                                <div class="card-body">
                                    <div class="text-center">
                                        <h1 class="blue-text"><i class="fas fa-money-check prefix"></i></h1>
                                        <h5 class="card-title grey-text">Account Details</h5>
                                    </div>    
                                    <div class="p-5 grey-text">
                                        <p class="card-text">Bank account details display here 'show only for first time users'. This is the default account used for payment by users. Account can change for registration,loan and making deposit but BVN must be the same.</p>
                                      
                                      <div class="mt-4">
                                        <a class="card-link" href="#" data-toggle="modal" data-target="#bankdetails">Update</a>
                                      </div>
                                      
                                    </div>
                                </div>
                              </div>
                              <!--Card end-->
                            </div>
                    </div>
                </div>
            </section>                
            <a title="back to top" id="back2Top" href="#" class="orange-text">&#10148</a>
        </div>
      </div>
    
</main>
<!--Main content-->
<!--Footer to be included here-->
  <!-- /Start your project here-->

  <!-- SCRIPTS -->
  <!-- JQuery -->
  <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="js/mdb.js"></script>
  <!--Google Maps-->
<!-- jQuery Custom Scroller CDN -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.concat.min.js"></script>
  
  <script>
      $('.carousel').carousel({
        interval: 3000,
      })
    </script>
    <script type="text/javascript">
      $(document).ready(function () {
          $("#sidebar").mCustomScrollbar({
              theme: "minimal"
          });

          $('#dismiss, .overlay').on('click', function () {
              $('#sidebar').removeClass('active');
              $('.overlay').removeClass('active');
          });

          $('#sidebarCollapse').on('click', function () {
              $('#sidebar').addClass('active');
              $('.overlay').addClass('active');
              $('.collapse.in').toggleClass('in');
              $('a[aria-expanded=true]').attr('aria-expanded', 'false');
          });
      });
  </script>
  <script type="text/javascript">
  /*Scroll to top when arrow up clicked BEGIN*/
  $(window).scroll(function() {
      var height = $(window).scrollTop();
      if (height > 100) {
          $('#back2Top').fadeIn();
      } else {
          $('#back2Top').fadeOut();
      }
  });
  $(document).ready(function() {
      $("#back2Top").click(function(event) {
          event.preventDefault();
          $("html, body").animate({ scrollTop: 0 }, "slow");
          return false;
      });
      $("#btnpersonal").click(function(){
        var errormessage = document.getElementById('errormessage');
        var firstname = document.getElementById('firstname');
        var middlename = document.getElementById('middlename');
        var surname = document.getElementById('surname');
        var phone = document.getElementById('phone');
        var line1 = document.getElementById('line1');
        var line2 = document.getElementById('line2');
        var dob = document.getElementById('dob');
        var marital = document.getElementById('marital');
        var nextkin = document.getElementById('nextkin');
        var nextkinphone = document.getElementById('nextkinphone');
        var nextkinline1 = document.getElementById('nextkinline1');
        var nextkinline2 = document.getElementById('nextkinline2');
        var state = document.getElementById('state');
        var lga = document.getElementById('lga');

        if((firstname.value.length < 3) || (isNaN(firstname.value) == false)){
          errormessage.innerHTML = 'please enter a valid first name';
        } else if((middlename.value.length < 3) || (isNaN(middlename.value) == false)){
          errormessage.innerHTML = 'please enter a valid middle name';
        } else if((surname.value.length < 3) || (isNaN(surname.value) == false)){
          errormessage.innerHTML = 'please enter a valid surname';
        } else if(phone.value.indexOf('+') != 0 || phone.value.length < 10){
          errormessage.innerHTML = 'please enter a valid phone number with country code';
        } else if(line1.value.length < 5){
          errormessage.innerHTML = 'please enter address line 1';
        } else if(dob.value == ''){
          errormessage.innerHTML = 'please enter your date of birth';
        } else if(marital.value == ''){
          errormessage.innerHTML = 'please select your marital status';
        } else if((nextkin.value.length < 5) || (isNaN(nextkin.value) == false)){
          errormessage.innerHTML = 'please enter your next of kin\'s full name';
        } else if(nextkinline1.value.length < 5){
          errormessage.innerHTML = 'please enter your next of kin\'s address line 1';
        } else if(nextkinphone.value.length < 10){
          errormessage.innerHTML = 'please enter a valid phone number with country code';
        } else {
          //update date
          $.ajax({
              type: "GET",
              url: "updatepersonaldata",
              data: {
                'user': 'abhay',
                'firstname': firstname.value,
                'middlename': middlename.value,
                'surname': surname.value,
                'phone': phone.value,
                'line1': line1.value,
                'line2': line2.value,
                'dob': dob.value,
                'marital': marital.value,
                'nextkin': nextkin.value,
                'nextkinphone': nextkinphone.value,
                'nextkinline1': nextkinline1.value,
                'nextkinline2': nextkinline2.value,
                'state': state.value,
                'lga': lga.value
              },
              success: function(data){
                $('#personaldetails').modal('hide');
                document.getElementById('personaldetailssuccess').innerHTML = "your personal data have been updated."
              },
              error: function(){
                alert('error');
              }
            });


        }
      });

      // $('#state').change(function(){
      //   <?php $filecontents //= Storage::disk('local')->get('nigerianstatesandlgas.json');
      //   $array = json_decode($filecontents, true);
      //   $cnt = 0;
      //   $stateid = 0;
      //  ?>
      //  var name = "<?php //echo count($array);?>";
      //  var lgastr = "";
      //  var z=0;
      //  for(z=0; z<parseInt("<?php //echo count($array);?>"); z++){
      //   <?php //$cnt = $cnt+1;?>
      //   alert();
      //   if(document.getElementById('state').value == "<?php //echo $array[$cnt]['state']['name']; ?>"){
      //     alert("yes");
      //     exit();
      //   }
      //  }

      // });
      
      
  });
   /*Scroll to top when arrow up clicked END*/
   </script>
</body>

</html>
