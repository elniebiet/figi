<?php /* C:\xampp\htdocs\figi\resources\views/index.blade.php */ ?>
<?php $__env->startSection('title','FIGI-Building Wealth and Happiness'); ?>
<?php $__env->startSection('content'); ?>

  
    <!-- contact modal -->
    <div class="modal fade" id="contact" tabindex="-1" role="dialog" aria-labelledby="contact" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" >Contact Us</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
                <form class="p-5 grey-text">
                    <div class="md-form form-sm"> <i class="fas fa-user prefix"></i>
                      <input type="text" id="form3" class="form-control form-control-sm">
                      <label for="form3">Your name</label>
                    </div>
                    <div class="md-form form-sm"> <i class="fas fa-envelope prefix"></i>
                      <input type="text" id="form2" class="form-control form-control-sm">
                      <label for="form2">Your email</label>
                    </div>
                    <div class="md-form form-sm"> <i class="fas fa-tag prefix"></i>
                      <input type="text" id="form32" class="form-control form-control-sm">
                      <label for="form34">Subject</label>
                    </div>
                    <div class="md-form form-sm"> <i class="fas fa-pencil-alt prefix"></i>
                      <textarea type="text" id="form8" class="md-textarea form-control form-control-sm" rows="4"></textarea>
                      <label for="form8">Your message</label>
                    </div>
                    <div class="text-center mt-4">
                      <button class="btn btn-primary">Send <i class="far fa-paper-planeml-1"></i></button>
                    </div>
                  </form>
                
            </div>
            <div class="modal-footer">

            </div>
          </div>
        </div>
      </div>
<!-- contact modal -->

<!-- login modal -->
<div class="modal fade" id="login" tabindex="-1" role="dialog" aria-labelledby="contact" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" >Login</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
            <form class="p-5 grey-text">
                <div class="md-form form-sm"> <i class="fas fa-user prefix"></i>
                  <input type="text" id="form3" class="form-control form-control-sm">
                  <label for="form3">Username</label>
                </div>
                <div class="md-form form-sm"> <i class="fas fa-lock prefix"></i>
                  <input type="password" id="form2" class="form-control form-control-sm">
                  <label for="form2">Password</label>
                </div>
                <div class="text-center mt-4">
                  <a data-toggle="modal" data-target="#signup" href=""><button class="btn btn-primary" >Sign up <i class="far fa-paper-planeml-1"></i></button></a>
                  <button class="btn btn-primary" type="submit">Login <i class="far fa-paper-planeml-1"></i></button>
                </div>
              </form>
            
        </div>
        <div class="modal-footer">
          <span class="text-blue"><a data-toggle="modal" data-target="#forgetpassword" href="">forgot Password?</a></span>
        </div>
      </div>
    </div>
  </div>
<!-- login modal -->


<!-- Sign up modal -->
<div class="modal fade" id="signup" tabindex="-1" role="dialog" aria-labelledby="contact" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" >Sign-Up</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
            <form class="p-5 grey-text" id="ajax">
                <p>Hello!</p>
                <p>Become a Figant in less than 5mins! Fill the form the below to begin.</p>
                <p class="red-text" id="signuperror"></p>
                <p class="green-text" id="signupsuccess"></p>
                <div class="md-form form-sm"> <i class="fas fa-user prefix"></i>
                  <input type="text" id="signupfname" class="form-control form-control-sm" autocomplete="off" required="required">
                  <label for="signupfname">Firstname</label>
                </div>
                <div class="md-form form-sm"> <i class="fas fa-phone prefix"></i>
                  <input type="text" id="signupphone" class="form-control form-control-sm" maxlength="14" autocomplete="off" required="required">
                  <label for="signupphone">+2348*******</label>
                  <small id="sphoneHelp" class="form-text text-muted red-text"></small>
                </div>
                <div class="text-center mt-4">
                  <button class="btn btn-primary" id="signupbtn" type="button">Sign up <i class="far fa-paper-planeml-1"></i></button>
                </div>
              </form>
            
        </div>
        <div class="modal-footer">
        
        </div>
      </div>
    </div>
  </div>
<!-- Sign up modal -->


    <!-- forget password modal -->
    <div class="modal fade" id="forgetpassword" tabindex="-1" role="dialog" aria-labelledby="contact" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" >Account Recovery</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <!--Username is gotten from login form if provided.-->
              <!--Validate username and answer to secret question then auto redirect to 'reset_password'-->
                <form class="p-5 grey-text">
                    <div class="md-form form-sm"> <i class="fas fa-user prefix"></i>
                      <input type="text" id="form3" class="form-control form-control-sm">
                      <label for="form3">Username</label>
                    </div>
                    <div class="md-form form-sm"> <i class="fas fa-user-lock prefix"></i>
                      <input type="text" id="form3" class="form-control form-control-sm">
                      <label for="form3">Answer Secret Question</label>
                    </div>
                    <div class="text-center mt-4">
                      <button class="btn btn-primary">Send <i class="far fa-paper-planeml-1"></i></button>
                    </div>
                  </form>
                
            </div>
            <div class="modal-footer">

            </div>
          </div>
        </div>
      </div>
<!-- forget password modal -->
<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
      <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner" role="listbox">
      <!-- Slide One - Set the background image for this slide in the line below -->
      <div class="carousel-item active" style="background-image: url('img/loan1.jpg')">
        <div class="carousel-caption d-none d-md-block">
          <!-- Heading -->
          <h1 class="display-4 font-weight-bold black-text pt-5 mb-2"><span class="orange-text">F</span>IGI</h1>
    
        
          <!-- Description -->
          <p class="lead  font-weight-bold blue-text">Building Wealth and Happiness</p>
          <button type="button" class="btn btn-primary">Read more<i class="fas fa-book ml-2"></i></button>

        </div>
      </div>
      <!-- Slide Two - Set the background image for this slide in the line below -->
      <!--<div class="carousel-item" style="background-image: url('img/loan1.jpg')">
        <div class="carousel-caption d-none d-md-block">
    
          <h3 class="display-4 font-weight-bold orange-text pt-5 mb-2">APPLY FOR LOAN</h3>
    
          <hr class="hr-dark">

          <p class="font-weight-bold blue-text">We offer interest free laons with no collateral</p>
          <button type="button" class="btn btn-primary">Read more<i class="fas fa-book ml-2"></i></button>

        </div>
      </div>-->
      <!-- Slide Three - Set the background image for this slide in the line below -->
      <div class="carousel-item" style="background-image: url('img/invest2.jpg')">
        <div class="carousel-caption d-none d-md-block">
          <h3 class="display-4 font-weight-bold orange-text pt-5 mb-2">SAVE AND INVEST</h3>
          <!-- Divider -->
          <hr class="hr-dark">
          <p class="font-weight-bold blue-text">This is a FinTech Application concerned with increasing financial inclusion</p>
          <button type="button" class="btn btn-primary">Read more<i class="fas fa-book ml-2"></i></button>

        </div>
      </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>
  </div>
            <section class="mt-5" id="about">

                  <h2 class="display-4 mb-4 font-weight-bold text-center">What we do</h2>
                  
                  <p>The background images for the slider are set directly in the HTML using inline CSS. The images in this snippet are from <a href="https://unsplash.com">Unsplash</a>, taken by <a href="https://unsplash.com/@joannakosinska">Joanna Kosinska</a>!</p>
                
              </section>
            
      <section id="services"  class="mt-5">
        
            <h2 class="display-4 mb-4 font-weight-bold text-center">Services</h2>
            
      
      <!--Grid row-->
      <div class="row">
    
          <!--Grid column-->
          <div class="col-md-4 mb-1">
              <i class="fas fa-clone fa-4x orange-text"></i>
              <h4 class="my-4 font-weight-bold">Take Loan</h4>
              <p class="grey-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reprehenderit maiores nam, aperiam minima
                  assumenda deleniti hic.<button class="btn btn-primary">Get started</button></p>
          </div>
          <!--Grid column-->
    
          <!--Grid column-->
          <div class="col-md-4 mb-1">
              <i class="fas fa-user-lock fa-4x orange-text"></i>
              <h4 class="my-4 font-weight-bold">Save Money</h4>
              <p class="grey-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reprehenderit maiores nam, aperiam minima
                  assumenda deleniti hic.<button class="btn btn-primary">Get started</button></p>
          </div>
          <!--Grid column-->
    
          <!--Grid column-->
          <div class="col-md-4 mb-1">
              <i class="fas fa-users fa-4x orange-text"></i>
              <h4 class="my-4 font-weight-bold">Transfer Money</h4>
              <p class="grey-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reprehenderit maiores nam, aperiam minima
                  assumenda deleniti hic.
                      <button class="btn btn-primary">Get started</button>
                </p>
          </div>
          <!--Grid column-->
    
      </div>
      <!--Grid row-->
      <hr class="my-5">
        <!--Grid row-->
        <div class="row">
      
          <!--Grid column-->
          <div class="col-lg-4 col-md-12 mb-4">
      
            <div class="view overlay z-depth-1-half">
              <img src="img/logo/home1.jpg" class="img-fluid">
              <a href="#!">
                <div class="mask rgba-white-slight"></div>
              </a>
            </div>
      
            <h4 class="my-4 font-weight-bold">HOUSE9ja</h4>
            <p class="grey-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reprehenderit maiores nam,
              aperiam minima
              assumenda deleniti hic. <button class="btn btn-primary">Read More...</button></p>
      
          </div>
          <!--Grid column-->
      
          <!--Grid column-->
          <div class="col-lg-4 col-md-6 mb-4">
      
            <div class="view overlay z-depth-1-half">
              <img src="img/invest1.jpg" class="img-fluid">
              <a href="#!">
                <div class="mask rgba-white-slight"></div>
              </a>
            </div>
      
            <h4 class="my-4 font-weight-bold">NITTAN</h4>
            <p class="grey-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reprehenderit maiores nam,
              aperiam minima
              assumenda deleniti hic.<button class="btn btn-primary">Read More...</button></p>
      
          </div>
          <!--Grid column-->
      
          <!--Grid column-->
          <div class="col-lg-4 col-md-6 mb-4">
      
            <div class="view overlay z-depth-1-half">
              <img src="img/invest1.jpg" class="img-fluid">
              <a href="#!">
                <div class="mask rgba-white-slight"></div>
              </a>
            </div>
      
            <h4 class="my-4 font-weight-bold">SEYA</h4>
            <p class="grey-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reprehenderit maiores nam,
              aperiam minima
              assumenda deleniti hic.<button class="btn btn-primary">Read More...</button></p>
      
          </div>
          <!--Grid column-->
      
        </div>
        <!--Grid row-->
      </section>
      
      <?php $__env->stopSection(); ?>
        
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>