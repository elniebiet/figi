<?php /* C:\xampp\htdocs\figi\resources\views/layout.blade.php */ ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <title><?php echo $__env->yieldContent('title','FIGI-Building Wealth and  Happiness'); ?></title>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo e(URL::asset('https://use.fontawesome.com/releases/v5.7.0/css/all.css')); ?>">
  <!-- Bootstrap core CSS -->
  <link href="<?php echo e(URL::asset('css/bootstrap.min.css')); ?>" rel="stylesheet">
  <!-- Material Design Bootstrap -->
  <link href="<?php echo e(URL::asset('css/mdb.min.css')); ?>" rel="stylesheet">
  <!-- Your custom styles (optional) -->
  <link href="<?php echo e(URL::asset('css/style.css')); ?>" rel="stylesheet">
  <link rel="stylesheet" href="<?php echo e(URL::asset('css/style3.css')); ?>">
  <link rel="icon" href="<?php echo e(URL::asset('img/logo/favicon.ico')); ?>">

    <!-- JQuery -->
  <script type="text/javascript" src="<?php echo e(URL::asset('js/jquery-3.3.1.min.js')); ?>"></script>
  
</head>

<body>
  <header>
    <div class="wrapper">
        <!--Sidebar-->  
        <nav id="sidebar">
            <div id="dismiss">
                <i class="fas fa-arrow-left"></i>
            </div>
    
            <div class="sidebar-header">
                <h3>APPS</h3>
            </div>
            <ul class="list-unstyled CTAs">
                <li>
                    <a href="#" class="download">FIGI</a>
                </li>
                <li>
                    <a href="#" class="article">HOUSE9ja</a>
                </li>
                <li>
                    <a href="#" class="article">NITTAN</a>
                </li>
                <li>
                    <a href="#" class="article">SEYA</a>
                </li>
            </ul>
        </nav>
      </div>   
<!-- Navigation -->
<nav class="navbar navbar-expand-lg navbar-light bg-dark">
  <div class="container">
      <button type="button" id="sidebarCollapse" class="btn btn-info">
          <i class="fas fa-align-left"></i>
          <span>APPS</span>
      </button>
    <a class="navbar-brand" href="/figi/public/"><img src="img/logo/FIGI LOGO.jpg" style="width: 100px;"></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon" style="color: #33b5e5;"></span>
        </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav ml-auto smooth-scroll">
        <li class="nav-item active">
          <a class="nav-link" href="/figi/public/">Home
                <span class="sr-only">(current)</span>
              </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#about">About</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#services">Services</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" data-toggle="modal" data-target="#contact" href="#">Contact</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-toggle="modal" data-target="#signup" href="#">Signup</a>
          </li>
        <li class="nav-item">
            <a class="nav-link" data-toggle="modal" data-target="#login" href="#">Login</a>
          </li>
      </ul>
    </div>
  </div>
</nav>
  
</header>
<!--main content-->
<main>

    <div class="mt-5">
        <div class="container">
            <?php echo $__env->yieldContent('content'); ?>
            <a title="back to top" id="back2Top" href="#" class="orange-text">&#10148</a>
        </div>
      </div>
   </main>
<!--Main content-->
<!-- Footer -->
<footer class="page-footer font-small unique-color-dark">
  <div class="primary-color">
      <div class="container">
          <!--Grid row-->
          <div class="row py-4 d-flex align-items-center">

              <!--First column-->
        <div class="col-md-3 col-lg-4 col-xl-3 mb-4">
            <h6 class="text-uppercase font-weight-bold">
                <strong>FIGI</strong>
            </h6>
            <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
            <p>
                <a href="#!">Apply for loan</a>
            </p>
            <p>
                <a href="#!">Save Money</a>
            </p>
            <p>
                <a href="#!">Transfer Money</a>
            </p>
            
        </div>
        <!--/.First column-->

        <!--Second column-->
        <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
            <h6 class="text-uppercase font-weight-bold">
                <strong>Products</strong>
            </h6>
            <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
            <p>
                <a href="#!">FIGI</a>
            </p>
            <p>
                <a href="#!">HOUSE9ja</a>
            </p>
            <p>
                <a href="#!">NITTAN</a>
            </p>
            <p>
                <a href="#!">SEYA</a>
            </p>
            </div>
        <!--/.Second column-->

        <!--Third column-->
        <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
            <h6 class="text-uppercase font-weight-bold">
                <strong>Useful links</strong>
            </h6>
            <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
            <p>
                <a href="#!">About FIGI</a>
            </p>

            <p>
                <a href="#!">Become a Figant</a>
            </p>
            <p>
                <a href="#!">Become a Merchant</a>
            </p>
            <p>
                <a href="#!">Help</a>
            </p>
        </div>
        <!--/.Third column-->

        <!--Fourth column-->
        <div class="col-md-4 col-lg-3 col-xl-3">
            <h6 class="text-uppercase font-weight-bold">
                <strong>Contact</strong>
            </h6>
            <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
            <p>
                <i class="fas fa-home  mr-3"></i> New York, NY 10012, US</p>
            <p>
                <i class="fas fa-envelope mr-3"></i> info@example.com</p>
            <p>
                <i class="fas fa-phone mr-3"></i> + 01 234 567 88</p>
            <p>
                <i class="fas fa-print mr-3"></i> + 01 234 567 89</p>
        </div>
        <!--/.Fourth column-->
                  
          </div>
          <!--Grid row-->
      </div>
  </div>

<!--/.Footer Links-->
  </footer>
  <!-- Copyright -->
  <div class="footer-copyright text-center py-3">© 2018 Copyright:
      <a href="#"> FIGI</a>
    </div>
    <!-- Copyright -->
  <!-- Footer -->
  <!-- /Start your project here-->

  <!-- SCRIPTS -->
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="<?php echo e(URL::asset('js/popper.min.js')); ?>"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="<?php echo e(URL::asset('js/bootstrap.min.js')); ?>"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="<?php echo e(URL::asset('js/mdb.js')); ?>"></script>
  <!--Google Maps-->
<!-- jQuery Custom Scroller CDN -->
<script src="<?php echo e(URL::asset('https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>

  <script>
      $('.carousel').carousel({
        interval: 3000,
      })
    </script>
    <script type="text/javascript">
      $(document).ready(function () {
          $("#sidebar").mCustomScrollbar({
              theme: "minimal"
          });

          $('#dismiss, .overlay').on('click', function () {
              $('#sidebar').removeClass('active');
              $('.overlay').removeClass('active');
          });

          $('#sidebarCollapse').on('click', function () {
              $('#sidebar').addClass('active');
              $('.overlay').addClass('active');
              $('.collapse.in').toggleClass('in');
              $('a[aria-expanded=true]').attr('aria-expanded', 'false');
          });
      });
  </script>
  <script type="text/javascript">
    /*Scroll to top when arrow up clicked BEGIN*/
        $(window).scroll(function() {
            var height = $(window).scrollTop();
            if (height > 100) {
                $('#back2Top').fadeIn();
            } else {
                $('#back2Top').fadeOut();
            }
        });
        $(document).ready(function() {
            $("#back2Top").click(function(event) {
                event.preventDefault();
                $("html, body").animate({ scrollTop: 0 }, "slow");
                return false;
            });
        
        });
         /*Scroll to top when arrow up clicked END*/
         </script>
          <script>
         /*jQuery(document).ready(function(){
            jQuery('#signupbtn').click(function(e){
               e.preventDefault();
               $.ajaxSetup({
                  headers: {
                      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                  }
              });
               
                  

               });
            });*/
      </script>
       <script type="text/javascript">
        $(document).ready(function(){
          var fname = document.getElementById("signupfname");
          var phone = document.getElementById("signupphone");
          var signupbtn = document.getElementById("signupbtn");
          $('#signupbtn').click(function(e){
            e.preventDefault();
               $.ajaxSetup({
                  headers: {
                      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                  }
              });
            var phonechar=phone.value.substring(1,phone.value.length);
            
            if(!(phone.value.indexOf("+")==0)){
              document.getElementById("sphoneHelp").innerHTML= "Start your phone number with your zip code";
              phone.value="";
            }else if(isNaN(phonechar) || phone.value.length<14){
              document.getElementById("sphoneHelp").innerHTML="Enter a valid phone number.";
              phone.value="";
            }else{
              jQuery.ajax({ 
                  url: "<?php echo e(url('/index')); ?>",
                  method: 'post',
                  data: {
                     fname: jQuery('#signupfname').val(),
                     phone: jQuery('#signupphone').val(),
                     type: 'signup'
                  },
                  success: function(data){
                    var details = JSON.parse(data);
                    if(details.length<2){
                      document.getElementById("sphoneHelp").innerHTML=details[0];
                      phone.value="";
                    }else{
                     window.location.href="signup?fname="+details[0]+"&p="+phonechar+"&vc="+details[2];
                    }
                  }});
            }
          });
        });
        


      </script>
     
    
</body>

</html>
