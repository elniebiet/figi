<?php /* C:\xampp\htdocs\figi\resources\views/home.blade.php */ ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title>FIGI-Building Wealth and  Happiness</title>
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css">
  <!-- Bootstrap core CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <!-- Material Design Bootstrap -->
  <link href="css/mdb.min.css" rel="stylesheet">
  <!-- Your custom styles (optional) -->
  <link href="css/style.css" rel="stylesheet">
  <link rel="stylesheet" href="css/style3.css">
  <link rel="icon" href="img/logo/favicon.ico">
</head>

<body>

  
    <!-- contact modal -->
    <div class="modal fade" id="contact" tabindex="-1" role="dialog" aria-labelledby="contact" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" >Contact Us</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
                <form class="p-5 grey-text">
                    <div class="md-form form-sm"> <i class="fas fa-user prefix"></i>
                      <input type="text" id="form3" class="form-control form-control-sm">
                      <label for="form3">Your name</label>
                    </div>
                    <div class="md-form form-sm"> <i class="fas fa-envelope prefix"></i>
                      <input type="text" id="form2" class="form-control form-control-sm">
                      <label for="form2">Your email</label>
                    </div>
                    <div class="md-form form-sm"> <i class="fas fa-tag prefix"></i>
                      <input type="text" id="form32" class="form-control form-control-sm">
                      <label for="form34">Subject</label>
                    </div>
                    <div class="md-form form-sm"> <i class="fas fa-pencil-alt prefix"></i>
                      <textarea type="text" id="form8" class="md-textarea form-control form-control-sm" rows="4"></textarea>
                      <label for="form8">Your message</label>
                    </div>
                    <div class="text-center mt-4">
                      <button class="btn btn-primary">Send <i class="far fa-paper-planeml-1"></i></button>
                    </div>
                  </form>
                
            </div>
            <div class="modal-footer">

            </div>
          </div>
        </div>
      </div>
<!-- contact modal -->

<!-- login modal -->
<div class="modal fade" id="login" tabindex="-1" role="dialog" aria-labelledby="contact" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" >Login</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
            <form class="p-5 grey-text">
                <div class="md-form form-sm"> <i class="fas fa-user prefix"></i>
                  <input type="text" id="form3" class="form-control form-control-sm">
                  <label for="form3">Username</label>
                </div>
                <div class="md-form form-sm"> <i class="fas fa-lock prefix"></i>
                  <input type="password" id="form2" class="form-control form-control-sm">
                  <label for="form2">Password</label>
                </div>
                <div class="text-center mt-4">
                  <a data-toggle="modal" data-target="#signup" href=""><button class="btn btn-primary" >Sign up <i class="far fa-paper-planeml-1"></i></button></a>
                  <button class="btn btn-primary">Login <i class="far fa-paper-planeml-1"></i></button>
                </div>
              </form>
            
        </div>
        <div class="modal-footer">
          <span class="text-blue"><a data-toggle="modal" data-target="#forgetpassword" href="">forgot Password?</a></span>
        </div>
      </div>
    </div>
  </div>
<!-- login modal -->


<!-- Sign up modal -->
<div class="modal fade" id="signup" tabindex="-1" role="dialog" aria-labelledby="contact" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" >Sign-Up</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
            <form class="p-5 grey-text">
                <p>Hello!</p>
                <p>Become a Figant in less than 5mins! Fill the form the below to begin.</p>
                <div class="md-form form-sm"> <i class="fas fa-user prefix"></i>
                  <input type="text" id="form3" class="form-control form-control-sm">
                  <label for="form3">Firstname</label>
                </div>
                <div class="md-form form-sm"> <i class="fas fa-phone prefix"></i>
                  <input type="password" id="form2" class="form-control form-control-sm">
                  <label for="form2">Phone number</label>
                </div>
                <div class="text-center mt-4">
                  <button class="btn btn-primary">Sign up <i class="far fa-paper-planeml-1"></i></button>
                </div>
              </form>
            
        </div>
        <div class="modal-footer">
        
        </div>
      </div>
    </div>
  </div>
<!-- Sign up modal -->


    <!-- forget password modal -->
    <div class="modal fade" id="forgetpassword" tabindex="-1" role="dialog" aria-labelledby="contact" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" >Account Recovery</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <!--Username is gotten from login form if provided.-->
              <!--Validate username and answer to secret question then auto redirect to 'reset_password'-->
                <form class="p-5 grey-text">
                    <div class="md-form form-sm"> <i class="fas fa-user prefix"></i>
                      <input type="text" id="form3" class="form-control form-control-sm">
                      <label for="form3">Username</label>
                    </div>
                    <div class="md-form form-sm"> <i class="fas fa-user-lock prefix"></i>
                      <input type="text" id="form3" class="form-control form-control-sm">
                      <label for="form3">Answer Secret Question</label>
                    </div>
                    <div class="text-center mt-4">
                      <button class="btn btn-primary">Send <i class="far fa-paper-planeml-1"></i></button>
                    </div>
                  </form>
                
            </div>
            <div class="modal-footer">

            </div>
          </div>
        </div>
      </div>
<!-- forget password modal -->
  <header>
    <div class="wrapper">
        <!--Sidebar-->  
        <nav id="sidebar">
            <div id="dismiss">
                <i class="fas fa-arrow-left"></i>
            </div>
    
            <div class="sidebar-header">
                <h3>APPS</h3>
            </div>
            <ul class="list-unstyled CTAs">
                <li>
                    <a href="#" class="download">FIGI</a>
                </li>
                <li>
                    <a href="#" class="article">HOUSE9ja</a>
                </li>
                <li>
                    <a href="#" class="article">NITTAN</a>
                </li>
                <li>
                    <a href="#" class="article">SEYA</a>
                </li>
            </ul>
        </nav>
      </div>   
<!-- Navigation -->
<nav class="navbar navbar-expand-lg navbar-light bg-dark">
  <div class="container">
      <button type="button" id="sidebarCollapse" class="btn btn-info">
          <i class="fas fa-align-left"></i>
          <span>APPS</span>
      </button>
    <a class="navbar-brand" href="/figi/public/"><img src="img/logo/FIGI LOGO.jpg" style="width: 100px;"></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon" style="color: #33b5e5;"></span>
        </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav ml-auto smooth-scroll">
        <li class="nav-item active">
          <a class="nav-link" href="/figi/public/">Home
                <span class="sr-only">(current)</span>
              </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#about">About</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#services">Services</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" data-toggle="modal" data-target="#contact" href="#">Contact</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-toggle="modal" data-target="#signup" href="#">Signup</a>
          </li>
        <li class="nav-item">
            <a class="nav-link" data-toggle="modal" data-target="#login" href="#">Login</a>
          </li>
      </ul>
    </div>
  </div>
</nav>
  <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
      <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
      <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner" role="listbox">
      <!-- Slide One - Set the background image for this slide in the line below -->
      <div class="carousel-item active" style="background-image: url('img/loan1.jpg')">
        <div class="carousel-caption d-none d-md-block">
          <!-- Heading -->
          <h1 class="display-4 font-weight-bold black-text pt-5 mb-2"><span class="orange-text">F</span>IGI</h1>
    
        
          <!-- Description -->
          <p class="lead  font-weight-bold blue-text">Building Wealth and Happiness</p>
          <button type="button" class="btn btn-primary">Read more<i class="fas fa-book ml-2"></i></button>

        </div>
      </div>
      <!-- Slide Two - Set the background image for this slide in the line below -->
      <!--<div class="carousel-item" style="background-image: url('img/loan1.jpg')">
        <div class="carousel-caption d-none d-md-block">
    
          <h3 class="display-4 font-weight-bold orange-text pt-5 mb-2">APPLY FOR LOAN</h3>
    
          <hr class="hr-dark">

          <p class="font-weight-bold blue-text">We offer interest free laons with no collateral</p>
          <button type="button" class="btn btn-primary">Read more<i class="fas fa-book ml-2"></i></button>

        </div>
      </div>-->
      <!-- Slide Three - Set the background image for this slide in the line below -->
      <div class="carousel-item" style="background-image: url('img/invest2.jpg')">
        <div class="carousel-caption d-none d-md-block">
          <h3 class="display-4 font-weight-bold orange-text pt-5 mb-2">SAVE AND INVEST</h3>
          <!-- Divider -->
          <hr class="hr-dark">
          <p class="font-weight-bold blue-text">This is a FinTech Application concerned with increasing financial inclusion</p>
          <button type="button" class="btn btn-primary">Read more<i class="fas fa-book ml-2"></i></button>

        </div>
      </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>
  </div>
</header>
<!--main content-->
<main>

    <div class="mt-5">
        <div class="container">
            <section class="mt-4" id="about">

                  <h2 class="mb-4 font-weight-bold text-center">What we do</h2>
                  
                  <p>The background images for the slider are set directly in the HTML using inline CSS. The images in this snippet are from <a href="https://unsplash.com">Unsplash</a>, taken by <a href="https://unsplash.com/@joannakosinska">Joanna Kosinska</a>!</p>
                
              </section>
            
      <section id="services">
        
            <h2 class="mb-4 font-weight-bold text-center">Services</h2>
            
      
      <!--Grid row-->
      <div class="row">
    
          <!--Grid column-->
          <div class="col-md-4 mb-1">
              <i class="fas fa-clone fa-4x orange-text"></i>
              <h4 class="my-4 font-weight-bold">Take Loan</h4>
              <p class="grey-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reprehenderit maiores nam, aperiam minima
                  assumenda deleniti hic.<button class="btn btn-primary">Get started</button></p>
          </div>
          <!--Grid column-->
    
          <!--Grid column-->
          <div class="col-md-4 mb-1">
              <i class="fas fa-user-lock fa-4x orange-text"></i>
              <h4 class="my-4 font-weight-bold">Save Money</h4>
              <p class="grey-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reprehenderit maiores nam, aperiam minima
                  assumenda deleniti hic.<button class="btn btn-primary">Get started</button></p>
          </div>
          <!--Grid column-->
    
          <!--Grid column-->
          <div class="col-md-4 mb-1">
              <i class="fas fa-users fa-4x orange-text"></i>
              <h4 class="my-4 font-weight-bold">Transfer Money</h4>
              <p class="grey-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reprehenderit maiores nam, aperiam minima
                  assumenda deleniti hic.
                      <button class="btn btn-primary">Get started</button>
                </p>
          </div>
          <!--Grid column-->
    
      </div>
      <!--Grid row-->
      <hr class="my-5">
        <!--Grid row-->
        <div class="row">
      
          <!--Grid column-->
          <div class="col-lg-4 col-md-12 mb-4">
      
            <div class="view overlay z-depth-1-half">
              <img src="img/logo/home1.jpg" class="img-fluid">
              <a href="#!">
                <div class="mask rgba-white-slight"></div>
              </a>
            </div>
      
            <h4 class="my-4 font-weight-bold">HOUSE9ja</h4>
            <p class="grey-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reprehenderit maiores nam,
              aperiam minima
              assumenda deleniti hic. <button class="btn btn-primary">Read More...</button></p>
      
          </div>
          <!--Grid column-->
      
          <!--Grid column-->
          <div class="col-lg-4 col-md-6 mb-4">
      
            <div class="view overlay z-depth-1-half">
              <img src="https://mdbootstrap.com/img/Photos/Others/images/52.jpg" class="img-fluid">
              <a href="#!">
                <div class="mask rgba-white-slight"></div>
              </a>
            </div>
      
            <h4 class="my-4 font-weight-bold">NITTAN</h4>
            <p class="grey-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reprehenderit maiores nam,
              aperiam minima
              assumenda deleniti hic.<button class="btn btn-primary">Read More...</button></p>
      
          </div>
          <!--Grid column-->
      
          <!--Grid column-->
          <div class="col-lg-4 col-md-6 mb-4">
      
            <div class="view overlay z-depth-1-half">
              <img src="img/invest1.jpg" class="img-fluid">
              <a href="#!">
                <div class="mask rgba-white-slight"></div>
              </a>
            </div>
      
            <h4 class="my-4 font-weight-bold">SEYA</h4>
            <p class="grey-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Reprehenderit maiores nam,
              aperiam minima
              assumenda deleniti hic.<button class="btn btn-primary">Read More...</button></p>
      
          </div>
          <!--Grid column-->
      
        </div>
        <!--Grid row-->
      </section>
      <a title="back to top" id="back2Top" href="#" class="orange-text">&#10148</a> 

        </div>
      </div>
   </main>
<!--Main content-->
<!-- Footer -->
<footer class="page-footer font-small unique-color-dark">
  <div class="primary-color">
      <div class="container">
          <!--Grid row-->
          <div class="row py-4 d-flex align-items-center">

              <!--First column-->
        <div class="col-md-3 col-lg-4 col-xl-3 mb-4">
            <h6 class="text-uppercase font-weight-bold">
                <strong>FIGI</strong>
            </h6>
            <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
            <p>
                <a href="#!">Apply for loan</a>
            </p>
            <p>
                <a href="#!">Save Money</a>
            </p>
            <p>
                <a href="#!">Transfer Money</a>
            </p>
            
        </div>
        <!--/.First column-->

        <!--Second column-->
        <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
            <h6 class="text-uppercase font-weight-bold">
                <strong>Products</strong>
            </h6>
            <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
            <p>
                <a href="#!">FIGI</a>
            </p>
            <p>
                <a href="#!">HOUSE9ja</a>
            </p>
            <p>
                <a href="#!">NITTAN</a>
            </p>
            <p>
                <a href="#!">SEYA</a>
            </p>
            </div>
        <!--/.Second column-->

        <!--Third column-->
        <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
            <h6 class="text-uppercase font-weight-bold">
                <strong>Useful links</strong>
            </h6>
            <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
            <p>
                <a href="#!">About FIGI</a>
            </p>

            <p>
                <a href="#!">Become a Figant</a>
            </p>
            <p>
                <a href="#!">Become a Merchant</a>
            </p>
            <p>
                <a href="#!">Help</a>
            </p>
        </div>
        <!--/.Third column-->

        <!--Fourth column-->
        <div class="col-md-4 col-lg-3 col-xl-3">
            <h6 class="text-uppercase font-weight-bold">
                <strong>Contact</strong>
            </h6>
            <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
            <p>
                <i class="fas fa-home  mr-3"></i> New York, NY 10012, US</p>
            <p>
                <i class="fas fa-envelope mr-3"></i> info@example.com</p>
            <p>
                <i class="fas fa-phone mr-3"></i> + 01 234 567 88</p>
            <p>
                <i class="fas fa-print mr-3"></i> + 01 234 567 89</p>
        </div>
        <!--/.Fourth column-->
                  
          </div>
          <!--Grid row-->
      </div>
  </div>

<!--/.Footer Links-->
  </footer>
  <!-- Copyright -->
  <div class="footer-copyright text-center py-3">© 2018 Copyright:
      <a href="#"> FIGI</a>
    </div>
    <!-- Copyright -->
  <!-- Footer -->
  <!-- /Start your project here-->

  <!-- SCRIPTS -->
  <!-- JQuery -->
  <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="js/mdb.js"></script>
  <!--Google Maps-->
<!-- jQuery Custom Scroller CDN -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.concat.min.js"></script>
  
  <script>
      $('.carousel').carousel({
        interval: 3000,
      })
    </script>
    <script type="text/javascript">
      $(document).ready(function () {
          $("#sidebar").mCustomScrollbar({
              theme: "minimal"
          });

          $('#dismiss, .overlay').on('click', function () {
              $('#sidebar').removeClass('active');
              $('.overlay').removeClass('active');
          });

          $('#sidebarCollapse').on('click', function () {
              $('#sidebar').addClass('active');
              $('.overlay').addClass('active');
              $('.collapse.in').toggleClass('in');
              $('a[aria-expanded=true]').attr('aria-expanded', 'false');
          });
      });
  </script>
  <script type="text/javascript">
    /*Scroll to top when arrow up clicked BEGIN*/
        $(window).scroll(function() {
            var height = $(window).scrollTop();
            if (height > 100) {
                $('#back2Top').fadeIn();
            } else {
                $('#back2Top').fadeOut();
            }
        });
        $(document).ready(function() {
            $("#back2Top").click(function(event) {
                event.preventDefault();
                $("html, body").animate({ scrollTop: 0 }, "slow");
                return false;
            });
        
        });
         /*Scroll to top when arrow up clicked END*/
         </script>
</body>

</html>
