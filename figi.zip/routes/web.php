<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('index');
});

/*Route::get('/home/{theSubject}', function ($theSubject) {
    return view($theSubject);
});*/
Route::get('/index', function () {
    return view('index');
});

Route::post('/index','FigiUserController@send');

Route::get('/signup', function () {
    return view('signup');
});

Route::post('/signup','FigiUserController@signupverification');

Route::get('/profile','FigiUserController@profile');
Route::get('/updatepersonaldata', 'FigiUserController@updatepersonaldata');

Route::post('/login','FigiUserController@login');
Route::get('/userdashboard', 'FigiUserController@userdashboard');