<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFigiusersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('figiusers', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('username',50)->unique();
            $table->string('password',150);
            $table->string('email',50)->unique();
            $table->string('fname',30);
            $table->string('mname', 30);
            $table->string('lname', 30);
            $table->string('phone',15);
            $table->integer('bankacctnum');
            $table->string('bankname',100);
            $table->string('dob',12);
            $table->integer('bvn');
            $table->string('nextofkin',100);
            $table->string('nextofkinphone',100);
            $table->string('address',250);
            $table->string('state',100);
            $table->string('country',100);
            $table->string('usertype',20);
            $table->tinyInteger('status');
            $table->dateTime('lastlogin');
            $table->dateTime('dateofsignup');
            $table->timestamps('');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('figiusers');
    }
}
