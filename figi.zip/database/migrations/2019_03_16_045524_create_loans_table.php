<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateLoansTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('loans', function (Blueprint $table) {
            $table->bigIncrements('loanid');
            $table->string('figinumber',30)->unique();
            $table->double('loanamount',12,2);
            $table->integer('loanacct');
            $table->string('g1figinumber',30);
            $table->tinyInteger('g1status');
            $table->string('g1phone',15);
            $table->string('g2figinumber',30);
            $table->tinyInteger('g2status');
            $table->string('g2phone',15);
            $table->string('g3figinumber',30);
            $table->tinyInteger('g3status');
            $table->string('g3phone',15);
            $table->string('g4figinumber',30);
            $table->tinyInteger('g4status');
            $table->string('g4phone',15);
            $table->dateTime('dateofapp');
            $table->tinyInteger('loanstage');
            $table->double('equitycont',12,2);
            $table->tinyInteger('equitycontstatus');
            $table->double('investment',12,2);
            $table->tinyInteger('loanstatus');
            $table->dateTime('dateapproved');
            $table->date('lastpayment');
            $table->string('approvedby',30);
            $table->string('supervisedby',100);
            $table->timestamps();    
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('loans');
    }
}
