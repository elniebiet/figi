<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\figiuser;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Storage;

class FigiUserController extends Controller
{
    /*Generates verification codes*/
    public function codegenerator($length,$Caracteres){ 
        //Under the string $Caracteres you write all the characters you want to be used to randomly generate the code. 
        //$Caracteres = 'ABCDEFGHIJKLMOPQRSTUVXWYZ0123456789'; 
        $characterlength = strlen($Caracteres); 
        $characterlength--; 
        
        $Hash=NULL; 
            for($x=1;$x<=$length;$x++){ 
                $position = rand(0,$characterlength); 
                $Hash .= substr($Caracteres,$position,1); 
            } 
        
        return strtolower($Hash); 
    } 

    public function myencode($str){

        return sha1($str);
    }

    public function send(Request $request)
    {
            $count = figiuser::where('phone', $request->phone)->count();
            if($count>0){
                $data = array("A user with ".$request->phone." already exist.");
                echo json_encode($data);
            }else{
                $fname=$request->fname;
                $phone=$request->phone;
                //generate verification code
                $caracters=$fname.substr($phone,1,strlen($phone));
                $verificationcode=$this->codegenerator('4',$caracters);
                //sms is sent here
                $data = array($fname,$phone,sha1($verificationcode));
                echo json_encode($data);
                //return redirect()->route('/signup', $data);
                
                // return response()->json(['data'=>$data]);
            }
    }

    public function signupverification(Request $request){
        if(isset($request->type) && $request->type=="finish"){
            $count =figiuser::where('username', $request->username)->count();
            if($count>0){
                return response()->json(['data'=>'Sorry, a user with this username already exist.']);
            }else{
                date_default_timezone_set("Africa/Lagos");
                $user = new figiuser();
                $user->username = $request->username;
                $user->password = $this->myencode($request->password);
                $user->fname = ucwords(strtolower($request->firstname));
                $user->phone=$request->phonenumber;
                $user->dateofsignup=data('Y/m/d');
                $user->status=1;
                $user->save();
                return response()->json(['data'=>"Congratulations ".ucwords(strtolower($request->firstname))."! You have signed up successfully with username: <span class='grean-text'>".$request->username."</span> <p><a href='index'>Login Here</a></p>"]);
            }
        }else{ 

        return response()->json(['data'=>$this->myencode($request->code)]);
        }
    }


    public function login(Request $request){
        
        try{
            date_default_timezone_set("Africa/Lagos");
            $username=$requet->lusername;
            $password=$request->lpassword;
            $user=figiuser::where('username', $username);

            if(empty($user->username)){
                return view('notauth')->with('username'=>$username,'e'=>0);
            }else if(!($this->myencode($password)==$user->password)){
                return view('notauth')->with('username'=>$username,'e'=>1);
            }else if($user->status!=1){
                return view('notauth')->with('username'=>$username,'e'=>2);
            }else{
                Session::set('userid', $user->id);
                Session::set('username', $user->username);
                DB::table('figiusers')->where('id', $user->id)->update(['lastlogin' =>date('Y/m/d H:i:s') ]);
                return view('userdashboard');
            }

        }catch(\Exception $e){

        }

    }

    public function profile(Request $request){
        $user = 'abhay';
        $getDetails = DB::table('figiusers')->where('username', $user);
        $firstname = $getDetails->value('fname');
        $phone = $getDetails->value('phone');
        return view('profile', ['firstname'=>$firstname, 'phone'=>$phone]);
    }
    public function updatepersonaldata(Request $request){
         $user = $request->user;
         $firstname = $request->firstname;
         $middlename = $request->middlename;
         $surname = $request->surname;
         $phone = $request->phone;
         $line1 = $request->line1;
         $line2 = $request->line2;
         $dob = $request->dob;
         $marital = $request->marital;

         $nextkin = $request->nextkin;
         $nextkinphone = $request->nextkinphone;
         $nextkinline1 = $request->nextkinline1;
         $nextkinline2 = $request->nextkinline2;
         $state = $request->state;
         $lga = $request->lga;

         $data = array(
            'fname'=>$firstname,
            'mname'=>$middlename,
            'lname'=>$surname, 
            'phone'=>$phone,
            'address1'=>$line1,
            'address2'=>$line2,
            'dob'=>$dob,
            'marital'=>$marital,
            'nextofkin'=>$nextkin,
            'nextofkinphone'=>$nextkinphone,
            'nextofkinaddress1'=>$nextkinline1,
            'nextofkinaddress2'=>$nextkinline2,
            'state'=>$state,
            'lga'=>$lga
         );
         DB::table('figiusers')->where('username', $user)->update($data);
         echo 'success';

    }

    public function userdashboard(Request $request){
        //check session is set before returning view
        return view('userdashboard');
    }
}
